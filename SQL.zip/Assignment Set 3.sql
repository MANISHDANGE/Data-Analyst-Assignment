use assignment;
/* 
1. Write a stored procedure that accepts the month and year as inputs and prints the ordernumber, orderdate and status of the orders placed in that month. 

Example:  call order_status(2005, 11);
*/

/*
begin

select orderdate,status from orders where year(orderdate)=order_year and month(orderdate)=month(str_to_date(order_month,'%b'));

end
*/

/*
2. Write a stored procedure to insert a record into the cancellations table for all cancelled orders.

STEPS: 

a.	Create a table called cancellations with the following fields

id (primary key), 
 	customernumber (foreign key - Table customers), 
ordernumber (foreign key - Table Orders), 
comments

All values except id should be taken from the order table.

b. Read through the orders table . If an order is cancelled, then put an entry in the cancellations table.
*/

#a 
CREATE TABLE cancellations (id int AUTO_INCREMENT, Ordernumber int NOT NULL, 
COMMENTS text, customernumber int NOT NULL, 
PRIMARY KEY (ID), FOREIGN KEY (customernumber) REFERENCES customers (customernumber),
FOREIGN KEY (ordernumber) REFERENCES orders (ordernumber));

#b
/*
create procedure sp_cancellations_record()

 begin

  insert into cancellations (ordernumber,comments,customernumber) select ordernumber,comments,customernumber from orders where status="Cancelled";
 end
*/


/*
3. 
a. Write function that takes the customernumber as input and returns the purchase_status based on the following criteria . [table:Payments]

if the total purchase amount for the customer is < 25000 status = Silver, amount between 25000 and 50000, status = Gold
if amount > 50000 Platinum

b. Write a query that displays customerNumber, customername and purchase_status from customers table.
*/

#a.
/*
create procedure sp_payment_status (in customerno int)
 begin
 select (case when amount<25000 then 'Silver' when amount<=50000 then 'Gold' when amount>50000 then 'Platinum' end) as purchase_status from payments where customernumber=customerno;
 end				
*/

#b.
select p.customernumber,customername,(case when amount<25000 then 'Silver' when amount<=50000 then 'Gold' when amount>50000 then 'Platinum' end) as purchase_status from payments as p inner join customers as c on c.customernumber=p.customernumber;


/*
4. Replicate the functionality of 'on delete cascade' and 'on update cascade' using triggers on movies and rentals tables. Note: Both tables - movies and rentals - don't have primary or foreign keys. Use only triggers to implement the above.
*/

/*
Update trigger for update cascade functionality

CREATE DEFINER=`root`@`localhost` TRIGGER `movies_AFTER_UPDATE` AFTER UPDATE ON `movies` FOR EACH ROW BEGIN

update rentals 
set movieid = new.id
where movieid = old.id;

END

*/

# 5. Select the first name of the employee who gets the third highest salary. [table: employee]

SELECT * FROM employee ORDER BY salary DESC LIMIT 1 OFFSET 2; 

# 6. Assign a rank to each employee  based on their salary. The person having the highest salary has rank 1. [table: employee]

select empid,salary ,rank() over(order by salary desc) salary_rank
from employee;










